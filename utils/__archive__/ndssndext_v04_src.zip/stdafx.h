#pragma once

#include <iostream>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
#include <memory.h>
#include <windows.h>
#include <shlwapi.h>
#include "inlines.h"

using namespace std;